sudo rmmod oToCAM
sudo rmmod oToSerDes

#sudo insmod ./oToSerDes.ko prdbg=1 fsync_int=30
sudo insmod ./oToSerDes.ko prdbg=1  repeater_en=1
#sudo insmod ./oToCAM.ko prdbg=1 fsync_mode=0
sudo insmod ./oToCAM.ko prdbg=1
ls /dev/video*
sleep 0.12

mode=$((1 + ${1:-0}))

# 0x38 轉為 10 進位是 56，0x3b 是 59
i=56
while [ "$i" -le 63 ]; do
    # 使用 printf 將 10 進位轉回 16 進位字串
    addr=$(printf "0x%02x" "$i")

    echo "====================================================="
    echo "🔍 正在檢查 I2C 設備位址: $addr ..."
    echo "====================================================="

    i2ctransfer -y -f 2 w2@"$addr" 0x0 0x0 r1 2>/dev/null

    if [ $? -ne 0 ]; then
        echo "⚠️  [錯誤] I2C 設備 $addr 沒有回應 (No ACK)！"
    else
        echo "✅ [成功] 發現設備 $addr，開始寫入暫存器設定..."
        i2ctransfer -y -f 2 w3@"$addr" 0x3 0x08 0x63 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x3 0x09 0x02 2>/dev/null
        i2ctransfer -y -f 2 w3@"$addr" 0x03 0x0b 0x"$mode" 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x3 0x0d 0x02 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x3 0x0f 0x00 2>/dev/null
        i2ctransfer -y -f 2 w3@"$addr" 0x3 0x11 0xf0 2>/dev/null
        i2ctransfer -y -f 2 w3@"$addr" 0x3 0x14 0xf0 2>/dev/null
        i2ctransfer -y -f 2 w3@"$addr" 0x3 0x15 0x80 2>/dev/null
        i2ctransfer -y -f 2 w3@"$addr" 0x3 0x16 0x5e 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x3 0x18 0x80 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x3 0x1a 0x5e 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x3 0x30 0x00 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x3 0x31 0x30 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x3 0x32 0xe4 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x3 0x33 0xe4 2>/dev/null
        # i2ctransfer -y -f 2 w3@"$addr" 0x0 0x02 0xf3 2>/dev/null
        i2ctransfer -y -f 2 w3@"$addr" 0x00 0x10 0x31 2>/dev/null
        echo "🎉 設備 $addr 設定完成！"
    fi
    echo ""

    # POSIX 標準的變數遞增寫法
    i=$((i + 1))
done

i2ctransfer -y -f 2 w2@0x4a 0x00 0x0 r1 2>/dev/null
# 2. 檢查上一個指令的結束狀態碼 ($? = 0 代表成功)
if [ $? -ne 0 ]; then
    echo "====================================================="
    echo "⚠️  [錯誤] I2C 設備 0x4a 沒有回應 (No ACK)！"
    echo "====================================================="
    # 根據你的腳本架構，這裡可以寫 exit 1 (直接結束) 或用 return 跳出當前 function
    # exit 1
else
    #---------------------------------------------------------------------------------------------------------Repeater     
    #i2ctransfer -y -f 2 w3@0x4a 0xFF 0xF8  0x94   # MAX9296 I2C ID
    i2ctransfer -y -f 2 w3@0x4a 0x00 0x10  0xB1    # Apply Reset Oneshot for changes and reset all
    #i2ctransfer -y -f 2 w3@0x4a 0xFF 0xFF  0x78   # Delay 120ms
    sleep 0.12
    #-----------------Deserializer MIPI CSI-2 PHY settings     
    i2ctransfer -y -f 2 w3@0x4a 0x03 0x30  0x04    # Set MIPI Phy Mode: 2x(1x4) mode, 
    i2ctransfer -y -f 2 w3@0x4a 0x03 0x33  0x4E    # lane maps - all 4 ports mapped straight
    i2ctransfer -y -f 2 w3@0x4a 0x03 0x34  0xE4    # Additional lane map
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x0A  0x00    # lane count - 0 lanes striping on controller 0 (Port A slave in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x4A  0xD0    # lane count - 4 lanes striping on controller 1 (Port A master in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x8A  0x00    # lane count - 0 lanes striping on controller 2 (Port B master in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x4a 0x04 0xCA  0x00    # lane count - 0 lanes striping on controller 3 (Port B slave in 2x1x4 mode).
    #-----------------Deserializer MIPI CSI-2 clock rate settings.     
    i2ctransfer -y -f 2 w3@0x4a 0x1D 0x00  0xF4    # (config_soft_rst_n - PHY1): 0x0
    i2ctransfer -y -f 2 w3@0x4a 0x03 0x1D  0x00    # MIPI clock rate - 1.5Gbps from controller 0 clock (Port A slave in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x4a 0x03 0x20  0x2c    # MIPI clock rate - 1.5Gbps from controller 1 clock (Port A master in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x4a 0x03 0x23  0x00    # MIPI clock rate - 1.5Gbps from controller 2 clock (Port B master in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x4a 0x03 0x26  0x00    # MIPI clock rate - 1.5Gbps from controller 3 clock (Port B slave in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x4a 0x1D 0x00  0xF5    # (config_soft_rst_n - PHY1): 0x1
    #-----------------Deserializer stream select programming.     
    i2ctransfer -y -f 2 w3@0x4a 0x00 0x50  0x00    # Route data from stream 0 to pipe X
    i2ctransfer -y -f 2 w3@0x4a 0x00 0x51  0x01    # Route data from stream 0 to pipe Y
    i2ctransfer -y -f 2 w3@0x4a 0x00 0x52  0x02    # Route data from stream 0 to pipe Z
    i2ctransfer -y -f 2 w3@0x4a 0x00 0x53  0x03    # Route data from stream 0 to pipe U
    i2ctransfer -y -f 2 w3@0x4a 0x03 0x32  0xF0    # Enable all PHYS.
    #-----------------Double Mode Configuration     
    #i2ctransfer -y -f 2 w3@0x4a 0x03 0x1C 0x10   # Enable pipe X, 8 processed as 16-bit color
    #i2ctransfer -y -f 2 w3@0x4a 0x03 0x1F 0x10   # Enable pipe X, write alternate map to RAMs
    #i2ctransfer -y -f 2 w3@0x4a 0x04 0x73 0x02   # Enabled 8-bit DT alternate memory map
    #-----------------Heartbeat     
    #i2ctransfer -y -f 2 w3@0x4a 0x01 0x00 0x23   # Pipe X disable heartbeat
    #i2ctransfer -y -f 2 w3@0x4a 0x01 0x12 0x23   # Pipe Y disable heartbeat
    #i2ctransfer -y -f 2 w3@0x4a 0x01 0x24 0x23   # Pipe Z disable heartbeat
    #i2ctransfer -y -f 2 w3@0x4a 0x01 0x36 0x23   # Pipe U disable heartbeat
    #-----------------Pipe X     
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x0B  0x07   # MAP_EN_L
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x2D  0x15   # MAP_DPHY_DEST
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x0D  0x00   # M0 source
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x0E  0x00   # M0 destination
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x0F  0x01   # M1 source
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x10  0x01   # M1 destination
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x11  0x12   # M2 source
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x12  0x12   # M2 destination
    #0x0413     # M3 source
    #0x0414     # M3 destination
          
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x4B  0x07   #07
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x6D  0x15   #15
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x4D  0x00   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x4E  0x00   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x4F  0x01   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x50  0x01   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x51  0x1E   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x52  0x1E   
    #0x0453   0x12   
    #0x0454   0x12   
    #-----------------Pipe Z     
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x8B  0x07   # 
    i2ctransfer -y -f 2 w3@0x4a 0x04 0xAD  0x15   # MAP_DPHY_DEST 10
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x8D  0x40   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x8E  0x40   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x8F  0x41   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x90  0x41   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x91  0x5E   
    i2ctransfer -y -f 2 w3@0x4a 0x04 0x92  0x5E   
    #0x0493     
    #0x0494     
    #-----------------Pipe U     
    #0x04CB   0x07   
    #0x04ED   0x15   # MAP_DPHY_DEST
    #0x04CD   0x00   
    #0x04CE   0x00   
    #0x04CF   0x01   
    #0x04D0   0x01   
    #0x04D1   0x2C   
    #0x04D2   0x2C   
    #0x04D3      
    #0x04D4      
    #-----------------GPO     
    i2ctransfer -y -f 2 w3@0x4a 0x00 0x05  0x40   # Disable LOCK
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xB5  0x0D   # GPIO1_GPIOC (Camera Lock) Rx ID : 0x0D
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xB4  0x60   # GPIO1_GPIOB (Camera Lock) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xB3  0x84   # GPIO1_GPIOA (Camera Lock) output enable, Rx source enable
    i2ctransfer -y -f 2 w3@0x4a 0x00 0x03  0x40   # Disable UART1
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xC1  0x05   # GPIO5_GPIOC (ISP ERRB) Rx ID : 0x05
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xC0  0x60   # GPIO5_GPIOB (ISP ERRB) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xBF  0x84   # GPIO5_GPIOA (ISP ERRB) output enable, Rx source enable
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xC4  0x1F   # GPIO6_GPIOC (Sensor ERRB) Rx ID : 0x1F
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xC3  0x60   # GPIO6_GPIOB (Sensor ERRB) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xC2  0x84   # GPIO6_GPIOA (Sensor ERRB) output enable, Rx source enable
    #-----------------GPI     
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xB1  0x6C   # GPIO0_GPIOB (ISP_reset) set I/O type -> Push-pull, Tx ID : 0x0C
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xB0  0x83   # GPIO0_GPIOA (ISP_reset) output disable, Tx source enable
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xC9  0x68   # GPIO8_GPIOB (FSYNC) set I/O type -> Push-pull, Tx ID : 0x08
    i2ctransfer -y -f 2 w3@0x4a 0x02 0xC8  0x83   # GPIO8_GPIOA (FSYNC) output disable, Tx source enable
fi
i2ctransfer -y -f 2 w2@0x42 0x00 0x0 r1 2>/dev/null
# 2. 檢查上一個指令的結束狀態碼 ($? = 0 代表成功)
if [ $? -ne 0 ]; then
    echo "====================================================="
    echo "⚠️  [錯誤] I2C 設備 0x42 沒有回應 (No ACK)！"
    echo "====================================================="
    # 根據你的腳本架構，這裡可以寫 exit 1 (直接結束) 或用 return 跳出當前 function
    # exit 1
else
    #i2ctransfer -y -f 2 w3@0x42 0xFF 0xF8  0x84   # MAX9295 I2C ID
    i2ctransfer -y -f 2 w3@0x42 0x00 0x10  0xA1    # Apply Reset Oneshot for changes and reset all
    #i2ctransfer -y -f 2 w3@0x42 0xFF 0xFF  0x78   # Delay 120ms
    sleep 0.12
    #-----------------Serializer MIPI CSI-2 PHY settings     
    i2ctransfer -y -f 2 w3@0x42 0x03 0x30  0x08    # Set SER to 1x4 mode (phy_config = 0), MIPI RX reset
    i2ctransfer -y -f 2 w3@0x42 0x03 0x32  0xE4    # Verify lane map is at its default (phy1_lane_map = 4'hE, phy0_lane_map = 4'h4 )
    i2ctransfer -y -f 2 w3@0x42 0x03 0x33  0xE4    # Additional lane map(phy3_lane_map = 4'hE, phy2_lane_map = 4'h4 )
    i2ctransfer -y -f 2 w3@0x42 0x03 0x31  0x33    # Set 4 lanes for serializer (ctrl1_num_lanes = 3)
    i2ctransfer -y -f 2 w3@0x42 0x03 0x11  0xF0    # Start video from port B pipe X,Y,Z,U. 
    i2ctransfer -y -f 2 w3@0x42 0x03 0x08  0x6F    # Enable info lines. Set X,Y,Z,U MIPI clock from port B (MAX9295A only have port B).
    #-----------------Serializer Datatype to Video Pipe routing     參考343
    i2ctransfer -y -f 2 w3@0x42 0x03 0x14  0x52    # Route Embedded 8-bit (DT = 0x12) to VIDEO_Z (Bit 6 enable)
    i2ctransfer -y -f 2 w3@0x42 0x03 0x16  0x5E    # Route YUV422 8bit (DT = 0x1E) to VIDEO_Y (Bit 6 enable)
    i2ctransfer -y -f 2 w3@0x42 0x03 0x18  0x5E    # Route YUV422 8bit (DT = 0x1E) to VIDEO_Z (Bit 6 enable)
    i2ctransfer -y -f 2 w3@0x42 0x03 0x1A  0x22    # Route RAW12 (DT = 0x2C) to VIDEO_U (Bit 6 enable)
    #-----------------Virtual channel     
    #0x0309   0x01   # PIPE X Select VC = 0
    i2ctransfer -y -f 2 w3@0x42 0x03 0x0B  0x01   # PIPE Y Select VC = 0
    i2ctransfer -y -f 2 w3@0x42 0x03 0x0D  0x02   # PIPE Z Select VC = 1
    #0x030F   0xFF   # PIPE U Select VC = 0,1,2,3
    #-----------------Heartbeat     
    #0x0102   0x0E   # Pipe X disable heartbeat
    #0x010A   0x0E   # Pipe Y disable heartbeat
    #0x0112   0x0E   # Pipe Z disable heartbeat
    #0x011A   0x0E   # Pipe U disable heartbeat
    #-----------------Double Mode Configuration     
    #0x0312   0x01   # Pipe X send 8-bit pixels as 16-bit
    #0x0313   0x80   # Pipe U send 12-bit pixels as 24-bit, Disable send 10-bit pixels as 20-bit
    #0x031C   0x30   # Pipe X BPP override enable, Virtual channel and Datatype override disabled
    #0x031D   0x18   # Pipe Y BPP, Virtual channel, Datatype override disabled
    #0x031E   0x18   # Pipe Z BPP, Virtual channel, Datatype override disabled
    #0x031F   0x38   # Pipe U BPP override enable, Virtual channel and Datatype override disabled
          
    #0x0108   0x60   # Pipe Y disable auto BPP
    #0x0109   0x10   # Manual set the BPP = 16bit per pixel on pipeline Y
    #0x0110   0x60   # Pipe Z disable auto BPP
    #0x0111   0x08   # Manual set the BPP = 8bit per pixel on pipeline Z
    #0x0118   0x60   # Pipe U disable auto BPP
    #0x0119   0x08   # Manual set the BPP = 8bit per pixel on pipeline U
    #-----------------Serializer enable video data transmission from serializer to deserializer.     
    i2ctransfer -y -f 2 w3@0x42 0x00 0x02  0x73   # Make sure all pipelines start transmission (VID_TX_EN_X,Y,Z,U = 1)
    i2ctransfer -y -f 2 w3@0x42 0x03 0x30  0x00   # Set SER to 1x4 mode (phy_config = 0), MIPI RX reset release
          
    #-----------------GPO     
    i2ctransfer -y -f 2 w3@0x42 0x02 0xC0  0x4C   # GPIO0_GPIOC (ISP_reset) Rx ID : 0x0C
    i2ctransfer -y -f 2 w3@0x42 0x02 0xBF  0x60   # GPIO0_GPIOB (ISP_reset) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x42 0x02 0xBE  0x84   # GPIO0_GPIOA (ISP_reset) output enable, Rx source enable
    i2ctransfer -y -f 2 w3@0x42 0x02 0xD8  0x48   # GPIO8_GPIOC (FSYNC) Rx ID : 0x08
    i2ctransfer -y -f 2 w3@0x42 0x02 0xD7  0x68   # GPIO8_GPIOB (FSYNC) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x42 0x02 0xD6  0x84   # GPIO8_GPIOA (FSYNC) output enable, Rx source enable
    #-----------------GPI     
    i2ctransfer -y -f 2 w3@0x42 0x02 0xCE  0x65   # GPIO5_GPIOB (ISP ERRB) set I/O type -> Push-pull, Tx ID : 0x05
    i2ctransfer -y -f 2 w3@0x42 0x02 0xCD  0x83   # GPIO5_GPIOA (ISP ERRB) output disable, Tx source enable
    i2ctransfer -y -f 2 w3@0x42 0x02 0xD1  0x7F   # GPIO6_GPIOB (Sensor ERRB) set I/O type -> Push-pull, Tx ID : 0x1F
    i2ctransfer -y -f 2 w3@0x42 0x02 0xD0  0x83   # GPIO6_GPIOA (Sensor ERRB) output disable, Tx source enable
    i2ctransfer -y -f 2 w3@0x42 0x02 0xD4  0x6D   # GPIO7_GPIOB (Camera Lock) set I/O type -> Push-pull, Tx ID : 0x0D
    i2ctransfer -y -f 2 w3@0x42 0x02 0xD3  0x83   # GPIO7_GPIOA (Camera Lock) output disable, Tx source enable
fi

i2ctransfer -y -f 2 w2@0x6c 0x00 0x0 r1 2>/dev/null
# 2. 檢查上一個指令的結束狀態碼 ($? = 0 代表成功)
if [ $? -ne 0 ]; then
    echo "====================================================="
    echo "⚠️  [錯誤] I2C 設備 0x6c 沒有回應 (No ACK)！"
    echo "====================================================="
    # 根據你的腳本架構，這裡可以寫 exit 1 (直接結束) 或用 return 跳出當前 function
    # exit 1
else
    #---------------------------------------------------------------------------------------------------------Repeater + Cable  
    #i2ctransfer -y -f 2 w3@0x6c 0xFF 0xF8  0x94   # MAX9296 I2C ID
    i2ctransfer -y -f 2 w3@0x6c 0x00 0x10  0xB1    # Apply Reset Oneshot for changes and reset all
    #i2ctransfer -y -f 2 w3@0x6c 0xFF 0xFF  0x78   # Delay 120ms
    sleep 0.12
    #-----------------Deserializer MIPI CSI-2 PHY settings     
    i2ctransfer -y -f 2 w3@0x6c 0x03 0x30  0x04    # Set MIPI Phy Mode: 2x(1x4) mode, 
    i2ctransfer -y -f 2 w3@0x6c 0x03 0x33  0x4E    # lane maps - all 4 ports mapped straight
    i2ctransfer -y -f 2 w3@0x6c 0x03 0x34  0xE4    # Additional lane map
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x0A  0x00    # lane count - 0 lanes striping on controller 0 (Port A slave in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x4A  0xD0    # lane count - 4 lanes striping on controller 1 (Port A master in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x8A  0x00    # lane count - 0 lanes striping on controller 2 (Port B master in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x6c 0x04 0xCA  0x00    # lane count - 0 lanes striping on controller 3 (Port B slave in 2x1x4 mode).
    #-----------------Deserializer MIPI CSI-2 clock rate settings.     
    i2ctransfer -y -f 2 w3@0x6c 0x1D 0x00  0xF4    # (config_soft_rst_n - PHY1): 0x0
    i2ctransfer -y -f 2 w3@0x6c 0x03 0x1D  0x00    # MIPI clock rate - 1.5Gbps from controller 0 clock (Port A slave in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x6c 0x03 0x20  0x26    # MIPI clock rate - 1.5Gbps from controller 1 clock (Port A master in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x6c 0x03 0x23  0x00    # MIPI clock rate - 1.5Gbps from controller 2 clock (Port B master in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x6c 0x03 0x26  0x00    # MIPI clock rate - 1.5Gbps from controller 2 clock (Port B slave in 2x1x4 mode).
    i2ctransfer -y -f 2 w3@0x6c 0x1D 0x00  0xF5    # (config_soft_rst_n - PHY1): 0x1
    #-----------------Deserializer stream select programming.     
    i2ctransfer -y -f 2 w3@0x6c 0x00 0x50  0x00    # Route data from stream 0 to pipe X
    i2ctransfer -y -f 2 w3@0x6c 0x00 0x51  0x01    # Route data from stream 0 to pipe Y
    i2ctransfer -y -f 2 w3@0x6c 0x00 0x52  0x02    # Route data from stream 0 to pipe Z
    i2ctransfer -y -f 2 w3@0x6c 0x00 0x53  0x03    # Route data from stream 0 to pipe U
    i2ctransfer -y -f 2 w3@0x6c 0x03 0x32  0xF0    # Enable all PHYS.
    #-----------------Double Mode Configuration     
    #0x031C   0x10   # Enable pipe X, 8 processed as 16-bit color
    #0x031F   0x10   # Enable pipe X, write alternate map to RAMs
    #0x0473   0x02   # Enabled 8-bit DT alternate memory map
    #-----------------Heartbeat     
    #0x0100   0x23   # Pipe X disable heartbeat
    #0x0112   0x23   # Pipe Y disable heartbeat
    #0x0124   0x23   # Pipe Z disable heartbeat
    #0x0136   0x23   # Pipe U disable heartbeat
    #-----------------Pipe X     
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x0B  0x07   # MAP_EN_L
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x2D  0x15   # MAP_DPHY_DEST
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x0D  0x00   # M0 source
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x0E  0x00   # M0 destination
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x0F  0x01   # M1 source
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x10  0x01   # M1 destination
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x11  0x12   # M2 source
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x12  0x12   # M2 destination
    #0x0413     # M3 source
    #0x0414     # M3 destination
          
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x4B  0x07   #07
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x6D  0x15   #15
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x4D  0x00   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x4E  0x00   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x4F  0x01   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x50  0x01   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x51  0x1E   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x52  0x1E   
    #0x0453   0x12   
    #0x0454   0x12   
    #-----------------Pipe Z     
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x8B  0x07   # 
    i2ctransfer -y -f 2 w3@0x6c 0x04 0xAD  0x15   # MAP_DPHY_DEST 10
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x8D  0x40   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x8E  0x40   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x8F  0x41   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x90  0x41   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x91  0x5E   
    i2ctransfer -y -f 2 w3@0x6c 0x04 0x92  0x5E   
    #0x0493     
    #0x0494     
    #-----------------Pipe U     
    #0x04CB   0x07   
    #0x04ED   0x15   # MAP_DPHY_DEST
    #0x04CD   0x00   
    #0x04CE   0x00   
    #0x04CF   0x01   
    #0x04D0   0x01   
    #0x04D1   0x2C   
    #0x04D2   0x2C   
    #0x04D3      
    #0x04D4      
    #-----------------GPO     
    i2ctransfer -y -f 2 w3@0x6c 0x00 0x05  0x40   # Disable LOCK
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xB5  0x0D   # GPIO1_GPIOC (Camera Lock) Rx ID : 0x0D
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xB4  0x60   # GPIO1_GPIOB (Camera Lock) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xB3  0x84   # GPIO1_GPIOA (Camera Lock) output enable, Rx source enable
    i2ctransfer -y -f 2 w3@0x6c 0x00 0x03  0x40   # Disable UART1
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xC1  0x05   # GPIO5_GPIOC (ISP ERRB) Rx ID : 0x05
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xC0  0x60   # GPIO5_GPIOB (ISP ERRB) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xBF  0x84   # GPIO5_GPIOA (ISP ERRB) output enable, Rx source enable
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xC4  0x1F   # GPIO6_GPIOC (Sensor ERRB) Rx ID : 0x1F
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xC3  0x60   # GPIO6_GPIOB (Sensor ERRB) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xC2  0x84   # GPIO6_GPIOA (Sensor ERRB) output enable, Rx source enable
    #-----------------GPI     
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xB1  0x6C   # GPIO0_GPIOB (ISP_reset) set I/O type -> Push-pull, Tx ID : 0x0C
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xB0  0x83   # GPIO0_GPIOA (ISP_reset) output disable, Tx source enable
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xC9  0x68   # GPIO8_GPIOB (FSYNC) set I/O type -> Push-pull, Tx ID : 0x08
    i2ctransfer -y -f 2 w3@0x6c 0x02 0xC8  0x83   # GPIO8_GPIOA (FSYNC) output disable, Tx source enable
fi
i2ctransfer -y -f 2 w2@0x40 0x00 0x0 r1 2>/dev/null
# 2. 檢查上一個指令的結束狀態碼 ($? = 0 代表成功)
if [ $? -ne 0 ]; then
    echo "====================================================="
    echo "⚠️  [錯誤] I2C 設備 0x40 沒有回應 (No ACK)！"
    echo "====================================================="
    # 根據你的腳本架構，這裡可以寫 exit 1 (直接結束) 或用 return 跳出當前 function
    # exit 1
else          
    #i2ctransfer -y -f 2 w3@0x40 0xFF 0xF8  0x84   # MAX9295 I2C ID
    i2ctransfer -y -f 2 w3@0x40 0x00 0x10  0xA1    # Apply Reset Oneshot for changes and reset all
    #i2ctransfer -y -f 2 w3@0x40 0xFF 0xFF  0x78   # Delay 120ms
    sleep 0.12
    #-----------------Serializer MIPI CSI-2 PHY settings     
    i2ctransfer -y -f 2 w3@0x40 0x03 0x30  0x08    # Set SER to 1x4 mode (phy_config = 0), MIPI RX reset
    i2ctransfer -y -f 2 w3@0x40 0x03 0x32  0xE4    # Verify lane map is at its default (phy1_lane_map = 4'hE, phy0_lane_map = 4'h4 )
    i2ctransfer -y -f 2 w3@0x40 0x03 0x33  0xE4    # Additional lane map(phy3_lane_map = 4'hE, phy2_lane_map = 4'h4 )
    i2ctransfer -y -f 2 w3@0x40 0x03 0x31  0x33    # Set 4 lanes for serializer (ctrl1_num_lanes = 3)
    i2ctransfer -y -f 2 w3@0x40 0x03 0x11  0xF0    # Start video from port B pipe X,Y,Z,U. 
    i2ctransfer -y -f 2 w3@0x40 0x03 0x08  0x6F    # Enable info lines. Set X,Y,Z,U MIPI clock from port B (MAX9295A only have port B).
    #-----------------Serializer Datatype to Video Pipe routing     參考343
    i2ctransfer -y -f 2 w3@0x40 0x03 0x14  0x52    # Route Embedded 8-bit (DT = 0x12) to VIDEO_Z (Bit 6 enable)
    i2ctransfer -y -f 2 w3@0x40 0x03 0x16  0x5E    # Route YUV422 8bit (DT = 0x1E) to VIDEO_Y (Bit 6 enable)
    i2ctransfer -y -f 2 w3@0x40 0x03 0x18  0x5E    # Route YUV422 8bit (DT = 0x1E) to VIDEO_Z (Bit 6 enable)
    i2ctransfer -y -f 2 w3@0x40 0x03 0x1A  0x22    # Route RAW12 (DT = 0x2C) to VIDEO_U (Bit 6 enable)
    #-----------------Virtual channel     
    #0x0309   0x01   # PIPE X Select VC = 0
    i2ctransfer -y -f 2 w3@0x40 0x03 0x0B  0x01   # PIPE Y Select VC = 0
    i2ctransfer -y -f 2 w3@0x40 0x03 0x0D  0x02   # PIPE Z Select VC = 1
    #0x030F   0xFF   # PIPE U Select VC = 0,1,2,3
    #-----------------Heartbeat     
    #0x0102   0x0E   # Pipe X disable heartbeat
    #0x010A   0x0E   # Pipe Y disable heartbeat
    #0x0112   0x0E   # Pipe Z disable heartbeat
    #0x011A   0x0E   # Pipe U disable heartbeat
    #-----------------Double Mode Configuration     
    #0x0312   0x01   # Pipe X send 8-bit pixels as 16-bit
    #0x0313   0x80   # Pipe U send 12-bit pixels as 24-bit, Disable send 10-bit pixels as 20-bit
    #0x031C   0x30   # Pipe X BPP override enable, Virtual channel and Datatype override disabled
    #0x031D   0x18   # Pipe Y BPP, Virtual channel, Datatype override disabled
    #0x031E   0x18   # Pipe Z BPP, Virtual channel, Datatype override disabled
    #0x031F   0x38   # Pipe U BPP override enable, Virtual channel and Datatype override disabled
          
    #0x0108   0x60   # Pipe Y disable auto BPP
    #0x0109   0x10   # Manual set the BPP = 16bit per pixel on pipeline Y
    #0x0110   0x60   # Pipe Z disable auto BPP
    #0x0111   0x08   # Manual set the BPP = 8bit per pixel on pipeline Z
    #0x0118   0x60   # Pipe U disable auto BPP
    #0x0119   0x08   # Manual set the BPP = 8bit per pixel on pipeline U
    #-----------------Serializer enable video data transmission from serializer to deserializer.     
    i2ctransfer -y -f 2 w3@0x40 0x00 0x02  0x73   # Make sure all pipelines start transmission (VID_TX_EN_X,Y,Z,U = 1)
    i2ctransfer -y -f 2 w3@0x40 0x03 0x30  0x00   # Set SER to 1x4 mode (phy_config = 0), MIPI RX reset release
          
    #-----------------GPO     
    i2ctransfer -y -f 2 w3@0x40 0x02 0xC0  0x4C   # GPIO0_GPIOC (ISP_reset) Rx ID : 0x0C
    i2ctransfer -y -f 2 w3@0x40 0x02 0xBF  0x60   # GPIO0_GPIOB (ISP_reset) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x40 0x02 0xBE  0x84   # GPIO0_GPIOA (ISP_reset) output enable, Rx source enable
    i2ctransfer -y -f 2 w3@0x40 0x02 0xD8  0x48   # GPIO8_GPIOC (FSYNC) Rx ID : 0x08
    i2ctransfer -y -f 2 w3@0x40 0x02 0xD7  0x68   # GPIO8_GPIOB (FSYNC) set I/O type -> Push-pull
    i2ctransfer -y -f 2 w3@0x40 0x02 0xD6  0x84   # GPIO8_GPIOA (FSYNC) output enable, Rx source enable
    #-----------------GPI     
    i2ctransfer -y -f 2 w3@0x40 0x02 0xCE  0x65   # GPIO5_GPIOB (ISP ERRB) set I/O type -> Push-pull, Tx ID : 0x05
    i2ctransfer -y -f 2 w3@0x40 0x02 0xCD  0x83   # GPIO5_GPIOA (ISP ERRB) output disable, Tx source enable
    i2ctransfer -y -f 2 w3@0x40 0x02 0xD1  0x7F   # GPIO6_GPIOB (Sensor ERRB) set I/O type -> Push-pull, Tx ID : 0x1F
    i2ctransfer -y -f 2 w3@0x40 0x02 0xD0  0x83   # GPIO6_GPIOA (Sensor ERRB) output disable, Tx source enable
    i2ctransfer -y -f 2 w3@0x40 0x02 0xD4  0x6D   # GPIO7_GPIOB (Camera Lock) set I/O type -> Push-pull, Tx ID : 0x0D
    i2ctransfer -y -f 2 w3@0x40 0x02 0xD3  0x83   # GPIO7_GPIOA (Camera Lock) output disable, Tx source enable
fi

#for otocam276ISP last/first link output fail
i2ctransfer -y -f 2 w3@0x4a 0x00 0x10  0x31 2>/dev/null