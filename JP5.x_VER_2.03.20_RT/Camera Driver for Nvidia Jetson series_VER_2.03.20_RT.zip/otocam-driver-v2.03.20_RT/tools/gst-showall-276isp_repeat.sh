#!/bin/bash
#set -x
start=0
declare -a gst_options

if [ $# -eq 0 ]; then
    for ((i=$start;i<8;i++)); do
        [ -e /dev/video$i ] || continue
        if [ -z "$1" ]; then
            # gst_options+=("v4l2src device=/dev/video$i ! videoflip method=rotate-180 ! fpsdisplaysink sync=0")
            # gst_options+=("v4l2src device=/dev/video$i ! videoflip method=horizontal-flip ! fpsdisplaysink sync=0")
            # gst_options+=("v4l2src device=/dev/video$i ! videoflip method=vertical-flip ! fpsdisplaysink sync=0 ")
            gst_options+=("v4l2src device=/dev/video$i !fpsdisplaysink sync=0")
            #gst_options+=("v4l2src device=/dev/video$i ! fpsdisplaysink sync=0 text-overlay=false -v")
        else
            gst_options+=("v4l2src device=/dev/video$i ! nvvidconv ! nvv4l2h265enc ! h265parse ! matroskamux ! multifilesink next-file=4 max-file-size=10000000 max-files=3 post-messages=true location=video$i-h265_%02d.mp4")
        fi
    done
    #echo "${gst_options[@]}"
    for ((j=0;j<5;j++)); do
        gst-launch-1.0 -e ${gst_options[@]} &
        sleep 5
        killall -9 gst-launch-1.0
        sleep 5
    done
else
    # 1. 根據 $1 的值，先決定好解析度
    if [ "$1" -eq 0 ]; then
        width=3840
        height=2160
    else
        width=512
        height=288
    fi

    # 2. 初始化一個空的字串（用來存放整串 pipeline）
    gst_cmd=""

    # 3. 尋找存在的 video 裝置並拼接指令
    for ((i=$start; i<8; i++)); do
        if [ -e "/dev/video$i" ]; then
            # 串接每一個管道，GStreamer 多管道之間只需要用空白隔開
            # 注意：在指令字串內，單引號要拿掉，由 Bash 來確保 caps 欄位是一個整體
            pipeline="v4l2src device=/dev/video$i ! video/x-raw,format=UYVY,width=$width,height=$height ! fpsdisplaysink sync=0"
            
            if [ -z "$gst_cmd" ]; then
                gst_cmd="$pipeline"
            else
                gst_cmd="$gst_cmd $pipeline"
            fi
        fi
    done
    # 4. 檢查是否有成功偵測到任何 video 裝置
    if [ -z "$gst_cmd" ]; then
        echo "錯誤：找不到任何 /dev/video 裝置！"
        exit 1
    fi
    
    for ((j=0;j<5;j++)); do
        echo "執行的指令：gst-launch-1.0 -e $gst_cmd"
        eval "gst-launch-1.0 -e $gst_cmd &"
        sleep 5
        killall -9 gst-launch-1.0
        sleep 5
    done
fi

